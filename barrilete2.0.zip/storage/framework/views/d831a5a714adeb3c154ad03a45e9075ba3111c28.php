<?php $__env->startSection('title', 'Buscador'); ?>
<?php $__env->startSection('content'); ?>
<?php 
$query = Request::get('query')
?>
<div class="searchResultContainer">
    <p class="searchFilter">
        <a class="<?php echo e(Request::get('sec') == 'articulos' ? 'active' : 'searchFilterLink'); ?>" href="<?php echo e(route('search',['query'=>$query,'sec'=>'articulos'])); ?>">Artículos</a>
        <a class="<?php echo e(Request::get('sec') == 'galerias' ? 'active' : 'searchFilterLink'); ?>" href="<?php echo e(route('search',['query'=>$query,'sec'=>'galerias'])); ?>">Galerías</a>
        <a class="<?php echo e(Request::get('sec') == 'encuestas' ? 'active' : 'searchFilterLink'); ?>" href="<?php echo e(route('search',['query'=>$query,'sec'=>'encuestas'])); ?>">Encuestas</a>
    </p>
    <p class="searchInfo">Se encontraron <?php echo e($resultado->total()); ?> resultados para la búsqueda: <b><?php echo e($query); ?></b></p>
    <?php $__empty_1 = true; $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="searchResult">
        <p class="searchDate"><?php echo e($pub->date); ?></p>
        <?php if(Request::get('sec') == 'articulos'): ?>
        <a class="searchTitle" href="<?php echo e(route('article',['id'=>$pub->id,'section'=>str_slug($pub->section->name),'title'=>str_slug($pub->title,'-')])); ?>"><?php echo e($pub->title); ?></a>
        <?php elseif(Request::get('sec') == 'galerias'): ?>
        <a class="searchTitle" href="<?php echo e(route('gallery',['id'=>$pub->id,'title'=>str_slug($pub->title,'-')])); ?>"><?php echo e($pub->title); ?></a>
        <?php elseif(Request::get('sec') == 'encuestas'): ?>
        <a class="searchTitle" href="<?php echo e(route('poll',['id'=>$pub->id,'title'=>str_slug($pub->title,'-')])); ?>"><?php echo e($pub->title); ?></a>
        <?php endif; ?>
        <p class="searchCopete"><?php echo e($pub->article_desc); ?></p>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <hr />
    <p>No hay artículos para mostrar</p>
    <?php endif; ?>
    <?php echo e($resultado->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>