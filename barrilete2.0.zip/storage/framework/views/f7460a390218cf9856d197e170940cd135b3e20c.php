<?php $__env->startSection('title',  __('Login')); ?>
<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <div class="dashboard-login">
        <p><img src="<?php echo e(asset('svg/log-in.svg')); ?>" /><?php echo e(__('Login')); ?></p>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($errors->has('email')): ?>
            <p class="invalid-feedback" role="alert"><?php echo e($errors->first('email')); ?></p>
            <?php endif; ?>
            <?php if($errors->has('password')): ?>
            <p class="invalid-feedback" role="alert"><?php echo e($errors->first('password')); ?></p>
            <?php endif; ?>            
            <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>" required autofocus>
            <input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
            <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
            <?php endif; ?>
            <input type="submit" value="Ingresar" />           
            <label class="check-container" for="remember"><?php echo e(__('Remember Me')); ?>

                <input type="checkbox" checked="checked" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <span class="check-mark"></span>
            </label>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>