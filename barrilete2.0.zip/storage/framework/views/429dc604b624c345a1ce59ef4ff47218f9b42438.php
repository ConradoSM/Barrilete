<div id="Article-container">
    <h1>Actualizar galería de fotos</h1>
        <fieldset>
            <legend>Información</legend>
            <p><b>Autor</b>: <?php echo e($gallery->user->name); ?></p>
            <p><b>Fecha de publicación</b>: <?php echo e($gallery->date); ?></p> 
        </fieldset>   
        <fieldset>
            <legend>Título</legend>           
                <div class="status"></div>
                <div class="data">
                    <p title="Editar"><?php echo e($gallery->title); ?></p>
                    <form action="<?php echo e(route('updateGallery')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="input" name="title" value="<?php echo e($gallery->title); ?>" placeholder="Título: éste es el principal título de la foto (*)" required /> 
                        <input type="submit" class="actualizar-datos" value="Actualizar" />
                        <input type="hidden" name="user_id" value="<?php echo e($gallery->user->id); ?>" />
                        <input type="hidden" name="date" value="<?php echo e($gallery->date); ?>" />
                        <input type="hidden" name="author" value="<?php echo e($gallery->author); ?>" />
                        <input type="hidden" name="section_id" value="<?php echo e($gallery->section_id); ?>" />
                        <input type="hidden" name="id" value="<?php echo e($gallery->id); ?>" />
                        <input type="hidden" name="article_desc" value="<?php echo e($gallery->article_desc); ?>" />
                    </form>
                </div>
        </fieldset> 
        <fieldset>
            <legend>Copete</legend>           
                <div class="status"></div>
                <div class="data">
                    <p title="Editar"><?php echo e($gallery->article_desc); ?></p>
                    <form action="<?php echo e(route('updateGallery')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <textarea name="article_desc" class="input" placeholder="Copete: puedes incluir el primer párrafo de tu artículo (*)" required><?php echo e($gallery->article_desc); ?></textarea>
                        <input type="submit" class="actualizar-datos" value="Actualizar" />
                        <input type="hidden" name="user_id" value="<?php echo e($gallery->user->id); ?>" />
                        <input type="hidden" name="date" value="<?php echo e($gallery->date); ?>" />
                        <input type="hidden" name="author" value="<?php echo e($gallery->author); ?>" />
                        <input type="hidden" name="section_id" value="<?php echo e($gallery->section_id); ?>" />
                        <input type="hidden" name="id" value="<?php echo e($gallery->id); ?>" />
                        <input type="hidden" name="title" value="<?php echo e($gallery->title); ?>" />
                    </form>
                </div>
        </fieldset>
        <fieldset id="cargar">
            <legend>Cargar más imagenes</legend>
            <input type="submit" value="SIGUIENTE >>" id="enviar" />
        </fieldset>
        <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <fieldset data-id="<?php echo e($photo->id); ?>">
            <div class="status"></div>           
            <div class="photo-gallery-container">
                <form action="<?php echo e(route('updatePhoto')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>                    
                    <input type="file" class="jfilestyle" data-placeholder="Seleccionar imagen" name="photo" accept="image/*" required />
                    <input type="submit" class="actualizar-foto" value="Actualizar" />
                    <input type="hidden" name="id" value="<?php echo e($photo->id); ?>" />
                    <input type="hidden" name="actual_photo" value="<?php echo e($photo->photo); ?>" />
                </form>
                <img class="update-image-button" src="<?php echo e(asset('svg/update.svg')); ?>" title="Actualizar imagen" />
                <img class="delete-image-button" src="<?php echo e(asset('svg/delete.svg')); ?>" title="Borrar imagen" />
                <img class="photo-gallery" src="<?php echo e(asset('img/galleries/'.$photo->photo)); ?>" />
            </div> 
            <div class="status"></div>
            <div class="data">
                <p title="Editar"><?php echo e($photo->title); ?></p>
                <form action="<?php echo e(route('updateTitlePhotoGallery')); ?>" method="post">
                    <?php echo csrf_field(); ?>                           
                    <input type="text" name="title" class="input" value="<?php echo e($photo->title); ?>" placeholder="Título: éste es el principal título de la foto (*)" required />
                    <input type="submit" class="actualizar-datos" value="Actualizar" /> 
                    <input type="hidden" name="id" value="<?php echo e($photo->id); ?>" />
                </form>
            </div>                   
        </fieldset>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay fotos</p>
        <?php endif; ?>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.filestyle.js')); ?>"></script>
    <script type="text/javascript">       
        $(document).ready(function () {                                            
           
            //MOSTRAR FORMULARIOS
            $('div.data p').click(function(){
                
                var parrafo = $(this);
                var form = $(this).parent('div').children('form');
                var input = $(form).children('.input');

                $(this).fadeOut('fast', function(){                       
                    $(form).fadeIn('fast', function(){                           
                        $(input).focus();                               
                    });
                });

                $(form).on('focusout', function(){                                   
                    $(form).fadeOut('fast', function(){                                        
                        $(parrafo).fadeIn('fast');                               
                    });
                });
            });

            //MOSTRAR FORM ACTUALIZAR FOTO
            $('img.update-image-button').on('click', function(){

                var form = $(this).parent('div').children('form');
                $(form).toggle('linear');
            });

            //ACTUALIZAR DATOS
            $('input[type=submit].actualizar-datos').on('click', function(event){
                event.stopPropagation();
                event.preventDefault();
                
                var div = $(this).parents('div.data');
                var parrafo = $(div).children('p');
                var form = $(div).children('form');
                var inputName = $(form).children('.input').attr('name');
                var divStatus = $(div).prev('div.status');
                
                $.ajax({
                    success: mostrarRespuesta,
                    error: mostrarError,
                    data: $(form).serialize(),
                    url: $(form).prop('action'),
                    type: $(form).prop('method'),
                    datatype: 'json',
                    async: true
                });
                
                function mostrarRespuesta(data){ 

                    var content = data[inputName];
                    if(data['Error']){

                        $(divStatus).hide().append('<p class="invalid-feedback">'+data['Error']+'</p>').fadeIn('fast'); 

                    } else {

                        $(divStatus).hide().append('<p class="alert-success">'+data['Exito']+'</p>').fadeIn('slow'); 
                        $(form).hide(0, function(){
                            $(form).children('.input').focusout();                         
                            $(parrafo).text(content);                           
                        });                      
                        setTimeout(function(){
                            $('p.alert-success').fadeOut('slow', function(){
                                $('p.alert-success').remove();
                            });
                        }, 2000);                        
                    } console.log(data);
                };
                
                function mostrarError(xhr){

                    var errors = xhr.responseJSON.errors;                   
                    $.each(errors, function(key,value){
                        $(divStatus).hide().append('<p class="invalid-feedback">'+value+'</p>').fadeIn('slow');      
                    }); 
                    console.log(errors);
                };               
                $('p.invalid-feedback').remove();
            });

            //ACTUALIZAR FOTO
            $('input[type=submit].actualizar-foto').click(function(event){
                event.stopPropagation();
                event.preventDefault();
                
                var div = $(this).parents('div.photo-gallery-container');
                var form = $(div).children('form');
                var formData = new FormData(form[0]);
                var divStatus = $(div).prev('div.status');
                var fotoActual =  $(div).children('img.photo-gallery'); 
                
                $.ajax({
                    success: mostrarRespuesta,
                    error: mostrarError,
                    data: formData,
                    url: $(form).prop('action'),
                    type: $(form).prop('method'),
                    datatype: 'json',
                    processData: false,
                    contentType: false,
                    async: true
                });
                
                function mostrarRespuesta(data){ 

                    if(data['Error']){

                        $(divStatus).hide().append('<p class="invalid-feedback">'+data['Error']+'</p>').fadeIn('fast'); 

                    } else {

                        $(divStatus).hide().append('<p class="alert-success">'+data['Exito']+'</p>').fadeIn('slow'); 
                        $(form).hide(0, function(){
                            $(fotoActual).remove();
                            $(form).children('input[name=actual_photo]').attr('value', data['Imagen']);
                            $(div).prepend('<img class="photo-gallery" src="img/galleries/'+data['Imagen']+'" />');
                        });                      
                        setTimeout(function(){
                            $('p.alert-success').fadeOut('slow', function(){
                                $('p.alert-success').remove();
                            });
                        }, 2000);                        
                    } console.log(data);
                };
                
                function mostrarError(xhr){

                    var errors = xhr.responseJSON.errors;                   
                    $.each(errors, function(key,value){
                        $(divStatus).hide().append('<p class="invalid-feedback">'+value+'</p>').fadeIn('slow');      
                    }); 
                    console.log(errors);
                };               
                $('p.invalid-feedback').remove();
            });  

            //ELIMINAR FOTO
            $('img.delete-image-button').click(function(){
                
                $('p.invalid-feedback').remove();

                var fieldset = $(this).parents('fieldset');
                var id = $(fieldset).data('id');

                if (confirm("¿Estás seguro que quieres eliminar la imagen?")) {

                    $.ajax({
                        url: '<?php echo route('deletePhotoGallery'); ?>',
                        type: 'POST',
                        data: { 'id': id, '_token': '<?php echo csrf_token(); ?>' },
                        success: function(data){
                            if(data['Error']){

                                $('<p class="invalid-feedback">'+data['Error']+'</p>').prependTo(fieldset).hide().fadeIn('slow');

                            } else {

                                $(fieldset).fadeOut('slow', function(){
                                    $(fieldset).before('<p class="alert-success">'+data['Exito']+'</p>').fadeIn('slow');
                                    $(fieldset).remove();                               
                                });
                                setTimeout(function(){
                                    $('p.alert-success').fadeOut('slow', function(){
                                        $('p.alert-success').remove();
                                    });
                                }, 2000);
                            }
                        },
                        error: function(data){
                            $('<p class="invalid-feedback">'+data['Error']+'</p>').prependTo(fieldset).hide().fadeIn('slow');
                        }
                    });

                } return false;
            });
            
            //CARGAR MAS FOTOS
            $('input#enviar').click(function(){
                
                $('p.invalid-feedback').remove();
                $.ajax({
                    url: '<?php echo route('morePhotos'); ?>',
                    type: 'POST',
                    data: { 'id': '<?php echo $gallery->id; ?>', '_token': '<?php echo csrf_token(); ?>' },                  
                    success: function(data){
                        if(data['Error']){
                            $('<p class="invalid-feedback">'+data['Error']+'</p>').prependTo('fieldset#cargar').hide().fadeIn('slow');
                        } else {
                            $('div#Article-container').html(data);
                        }
                    },
                    error: function(data){
                        $('<p class="invalid-feedback">'+data['Error']+'</p>').prependTo('fieldset#cargar').hide().fadeIn('slow');
                    }
                });
            });
        });
    </script>
</div>