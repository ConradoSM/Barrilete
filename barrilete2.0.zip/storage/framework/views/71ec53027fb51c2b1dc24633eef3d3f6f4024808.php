<div id="Article-container">
    <?php if(isset($Exito)): ?>
    <p class="alert-success"><?php echo e($Exito); ?></p>
    <?php endif; ?>
    <h1>Administra el artículo</h1>
    <div class="article-admin">
        <?php if(Auth::user()->is_admin): ?>
            <?php if($article->status == "DRAFT"): ?>
                <a href="<?php echo e(route('publishArticle',['id'=>$article->id])); ?>" class="edit" id="publish">Publicar</a>
            <?php else: ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('article',['id'=>$article->id,'section'=>str_slug($article->section->name),'title'=>str_slug($article->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
            <?php endif; ?>      
            <a href="<?php echo e(route('formUpdateArticle',['id'=>$article->id])); ?>" class="edit" id="edit">Editar</a>
            <a href="<?php echo e(route('deleteArticle',['id'=>$article->id])); ?>" class="delete" id="delete">Eliminar</a>
        <?php else: ?>
            <?php if($article->status == "PUBLISHED"): ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('article',['id'=>$article->id,'section'=>str_slug($article->section->name),'title'=>str_slug($article->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
                <a href="<?php echo e(route('formUpdateArticle',['id'=>$article->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deleteArticle',['id'=>$article->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php else: ?>
                <a href="#" class="disabled">No publicado</a>
                <a href="<?php echo e(route('formUpdateArticle',['id'=>$article->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deleteArticle',['id'=>$article->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <article class="pub-preview">
        <img src="<?php echo e(asset('img/articles/images/'.$article->photo)); ?>" title="<?php echo e($article->title); ?>" alt="<?php echo e($article->title); ?>" />
        <p class="info"><img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($article->date); ?></p>
        <h2><?php echo e($article -> title); ?></h2>
        <p class="copete"><?php echo e($article->article_desc); ?></p>
        <p class="info">
        <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($article->user->name); ?>

        <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($article->views); ?> lecturas
        </p>
        <hr />
        <?php echo $article->article_body; ?>

    </article>
<script type="text/javascript" src="<?php echo e(asset('js/admin-links.js')); ?>"></script>
</div>