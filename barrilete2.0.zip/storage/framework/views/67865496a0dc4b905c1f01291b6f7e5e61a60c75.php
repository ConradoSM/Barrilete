<div id="user-articles-list">
    <h1>Mis <?php echo e($status); ?></h1>
    <p>Se encontraron <?php echo e($Articles->total()); ?> <?php echo e($status); ?></p>
    <?php $__empty_1 = true; $__currentLoopData = $Articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="searchResult">
        <p class="searchDate">
            <?php if($article->status == 'DRAFT'): ?>
            <img src="<?php echo e(asset('svg/forbidden.svg')); ?>" title="No publicado" />
            <?php else: ?>
            <img src="<?php echo e(asset('svg/checked.svg')); ?>" title="Publicado" />
            <?php endif; ?>
            <?php echo e($article->date); ?>

        </p>
        <?php if($status == 'artículos'): ?>
        <a class="searchTitle" href="<?php echo e(route('previewArticle', ['id'=>$article->id])); ?>"><?php echo e($article->title); ?></a>
        <?php elseif($status == 'galerías'): ?>
        <a class="searchTitle" href="<?php echo e(route('previewGallery', ['id'=>$article->id])); ?>"><?php echo e($article->title); ?></a>
        <?php elseif($status == 'encuestas'): ?>
        <a class="searchTitle" href="<?php echo e(route('previewPoll', ['id'=>$article->id])); ?>"><?php echo e($article->title); ?></a>
        <?php endif; ?>
        <p class="searchCopete"><?php echo e($article->article_desc); ?></p>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
        <?php echo e($Articles->links()); ?>

</div>
<script type="text/javascript">
    $(document).ready(function () {

        $('div#user-articles-list a').each(function () {

            var href = $(this).attr('href');
            $(this).attr({href: '#'});

            $(this).click(function () {
                $('#user-articles-list').fadeOut('fast', 'linear', function () {
                    $('#loader').fadeIn('fast', 'linear', function () {
                        $('#loader').fadeOut('fast', 'linear', function () {
                            $('#user-content').fadeOut('fast', 'linear', function () {
                                $('#user-content').load(href, function () {
                                    $('#user-content').fadeIn('fast', 'linear');
                                });
                            });
                        });
                    });
                });
            });
        });
    });
</script>