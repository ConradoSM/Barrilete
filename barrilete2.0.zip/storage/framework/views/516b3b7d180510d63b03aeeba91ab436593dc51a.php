<h2>Borrar artículo</h2>
<?php if($status == 'success'): ?>
	<p class="alert-success">El artículo se ha eliminado correctamente del sistema.</p>
<?php elseif($status == 'error_delete'): ?>
	<p class="invalid-feedback">Ha ocurrido un error al borrar el artículo.</p>
<?php elseif($status == 'error_find'): ?>
	<p class="invalid-feedback">El artículo no existe.</p>
<?php endif; ?>