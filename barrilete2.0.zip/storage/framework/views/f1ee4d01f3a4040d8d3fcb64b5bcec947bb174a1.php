<?php $__env->startSection('title','Error: artículo no encontrado'); ?>
<?php $__env->startSection('content'); ?>
<article class="pub">
        <h1>Error - Artículo no encontrado</h1>
    <h3>El servidor no encuentra la noticia solicitada por el cliente. Esto puede deberse a que:</h3>
    <ol>
        <li>El cliente escribió mal la URL.</li>
        <li>La estructura de enlaces permanentes del sitio ha sido cambiada, por ejemplo, cuando un sitio ha sido trasladado a otro servidor web y el DNS todavía apunta a la ubicación anterior.</li>
        <li>La página web solicitada no está disponible temporalmente, pero puede intentarlo de nuevo más tarde.</li>
        <li>Se eliminó definitivamente la página web.</li>
    </ol>
    <br />
    <a href="<?php echo e(route('default')); ?>">Volver al inicio</a>
</article>
<img class="errorIMG" src="<?php echo e(asset('img/error.gif')); ?>" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>