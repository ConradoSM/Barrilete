<div id="Article_Form">
<h1>Cargar encuesta</h1>
    <form method="post" enctype="multipart/form-data" id="createArticle" action="<?php echo e(route('createPoll')); ?>">
        <fieldset>
            <legend>Información</legend>
            <p><b>Autor</b>: <?php echo e(Auth::user()->name); ?></p>
            <p><b>Fecha de publicación</b>: <?php echo e(date('Y-m-d h:i')); ?></p> 
        </fieldset>
        <fieldset>
            <legend>Título y Copete</legend>
            <div id="errors"></div>
            <input type="text" name="title" value="" placeholder="Título: éste es el principal título del articulo (*)" required />            
            <textarea name="article_desc" placeholder="Copete: puedes incluir el primer párrafo de tu artículo (*)" required></textarea>
            <input type="submit" value="SIGUIENTE >>" id="enviar" />
        </fieldset>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />
        <input type="hidden" name="date" value="<?php echo e(date('Y-m-d h:i')); ?>" />
        <input type="hidden" name="author" value="<?php echo e(Auth::user()->name); ?>" />
        <input type="hidden" name="section_id" value="<?php echo e($section->id); ?>" />
    </form>
</div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.filestyle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.form.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/formSubmit.js')); ?>"></script>