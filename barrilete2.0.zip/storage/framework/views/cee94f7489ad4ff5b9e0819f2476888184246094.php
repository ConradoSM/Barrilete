<?php $__env->startSection('title', 'Barrilete'); ?>
<?php $__env->startSection('description', 'Galerías de fotos'); ?>
<?php $__env->startSection('keywords', 'secciones, noticias, economía, editoriales, internacionales, galerías de fotos, tecnología, política, sociedad, encuestas, deportes, cultura'); ?>
<?php $__env->startSection('content'); ?>
<?php ($i=0) ?>
<?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php ($i++) ?>
    <article class="pubIndex">
        <?php if($i == 1): ?>
        <img src="<?php echo e(asset('img/galleries/'.$galeria->photos->first()->photo)); ?>" title="<?php echo e($galeria->title); ?>" alt="<?php echo e($galeria->title); ?>" />
        <?php else: ?>
        <img src="<?php echo e(asset('img/galleries/'.$galeria->photos->first()->photo)); ?>" title="<?php echo e($galeria->title); ?>" alt="<?php echo e($galeria->title); ?>" />
        <?php endif; ?>
        <a href="<?php echo e(route('gallery',['id'=>$galeria->id,'titulo'=>str_slug($galeria->title,'-')])); ?>"><?php echo e($galeria->title); ?></a>
        <p><?php echo e($galeria -> article_desc); ?></p>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1>No hay artículos para mostrar</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>