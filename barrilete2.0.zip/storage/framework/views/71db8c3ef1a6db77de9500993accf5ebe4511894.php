<!doctype html>
<html lang="es">
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="author" content="Conrado Maranguello" />
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
        <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/contenido.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/titularesIndex.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/forms.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>" />
        <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    </head>
    <body>
        <section class="dashboard">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <footer>
            <div class="footerContainer">
                <div>
                    <h2>Contacto</h2>
                    <ul>
                        <li><a href="mailto:info@barrilete.com.ar">info@barrilete.com.ar</a></li>
                    </ul>
                </div>
                <div>
                    <h2>Institucional</h2>
                    <p class="footerCopyright">Conrado Maranguello, responsable editorial</p>
                    <p class="footerCopyright">©2016 - 2019 todos los derechos reservados<br />Versión: 2.0 02122018 build 18.30 BETA</p>
                </div>
                <div class="footerSocialContainer">
                    <img src="<?php echo e(asset('svg/logo_barrilete.svg')); ?>" />
                    <img src="<?php echo e(asset('svg/facebook.svg')); ?>" class="footerSocialFacebook" />
                    <img src="<?php echo e(asset('svg/twitter.svg')); ?>" class="footerSocialTwitter" />
                </div>
            </div>                
        </footer>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>