<?php $__env->startSection('title', __('Reset Password')); ?>
<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <div class="dashboard-login">
        <p><img src="<?php echo e(asset('svg/lock.svg')); ?>" /><?php echo e(__('Reset Password')); ?></p>
         <?php if(session('status')): ?><p class="alert-success" role="alert"><?php echo e(session('status')); ?></p><?php endif; ?>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($errors->has('email')): ?>
            <p class="invalid-feedback" role="alert"><?php echo e($errors->first('email')); ?></p>
            <?php endif; ?>
            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>" required>
            <input type="submit" value="<?php echo e(__('Send Password Reset Link')); ?>" />
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>