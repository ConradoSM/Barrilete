<?php $__env->startSection('title', 'Barrilete'); ?>
<?php $__env->startSection('content'); ?>
<?php ($i=0) ?>
<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php ($i++) ?>
    <article class="pubIndex">
        <div class="seccion" onclick="location.href ='<?php echo e(route('section', ['section' => $sec -> section -> name ])); ?>'"><?php echo e($sec -> section -> name); ?></div>
        <?php if($sec -> video == 1): ?><img src="<?php echo e(asset('img/play-button.png')); ?>" class="video" /><?php endif; ?>
        <?php if($i == 1): ?>
        <img src="<?php echo e(asset('/img/articles/images/'.$sec -> photo)); ?>" title="<?php echo e($sec -> title); ?>" alt="<?php echo e($sec -> title); ?>" />
        <?php else: ?>
        <img src="<?php echo e(asset('/img/articles/.thumbs/images/'.$sec->photo)); ?>" title="<?php echo e($sec -> title); ?>" alt="<?php echo e($sec -> title); ?>" />
        <?php endif; ?>
        <a href="<?php echo e(route('article', ['id' => $sec -> id, 'section' => $sec -> section -> name ,'title' => str_slug($sec -> title, '-')])); ?>"><?php echo e($sec -> title); ?></a>
        <p><?php echo e($sec -> article_desc); ?></p>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1>No hay artículos para mostrar</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>