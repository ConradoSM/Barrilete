<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="tools">
        <div class="dashboard-title"><img src="<?php echo e(asset('svg/logo_barrilete.svg')); ?>" onclick="location.href ='<?php echo e(route('default')); ?>'" title="Home" alt="Home" /></div>
        <div id="user-menu">
            <p><?php echo e(Auth::user()->name); ?><img src="<?php echo e(asset('svg/arrow-down.svg')); ?>" /></p>
            <div id="user-options">
                <a href="#"><img src="<?php echo e(asset('svg/options.svg')); ?>" />Opciones</a>
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><img src="<?php echo e(asset('svg/log-out.svg')); ?>" /><?php echo e(__('Logout')); ?></a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
            </div>
        </div>                   
    </div>
    <div class="tools-bar">
        <h2>Mis publicaciones</h2>
        <a href="<?php echo e(route('viewArticles',['id' => Auth::user() -> id])); ?>" class="selected"><img src="<?php echo e(asset('svg/file.svg')); ?>" />Artículos</a>
        <a href="<?php echo e(route('viewGalleries',['id' => Auth::user() -> id])); ?>"><img src="<?php echo e(asset('svg/image.svg')); ?>" />Galerías</a>
        <a href="<?php echo e(route('viewPolls',['id' => Auth::user() -> id])); ?>"><img src="<?php echo e(asset('svg/analytics.svg')); ?>" />Encuestas</a>
        <h2>Cargar publicaciones</h2>
        <a href="<?php echo e(route('formCreateArticle')); ?>"><img src="<?php echo e(asset('svg/add-file.svg')); ?>" />Artículos</a>
        <a href="<?php echo e(route('formGallery')); ?>"><img src="<?php echo e(asset('svg/image.svg')); ?>" />Galerías</a>
        <a href="<?php echo e(route('formPoll')); ?>"><img src="<?php echo e(asset('svg/note.svg')); ?>" />Encuestas</a>
    </div>
    <div id="loader"><center><img src="<?php echo e(asset('img/loader.gif')); ?>" /></center></div>
    <div id="user-content"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {

        $('#user-content').load('<?php echo e(route('viewArticles',['id' => Auth::user() -> id])); ?>').prepend('<div id="loader"><center><img src="<?php echo e(asset("img/loader.gif")); ?>" /></center></div>').hide().fadeIn('normal');

        $('div.tools-bar a').each(function () {

            var href = $(this).attr('href');
            $(this).attr({href: '#'});

            $(this).click(function () {

                $('div.tools-bar a').removeClass('selected');
                $(this).addClass('selected');
                $('#loader').fadeIn('fast', 'linear');

                $('#user-content').hide(0, function () {
                    $('#user-content').load(href, function () {
                        $('#loader').fadeOut('fast', 'linear', function () {
                            $('#user-content').fadeIn('slow', 'linear');
                        });
                    });
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>