<?php $__env->startSection('title', $poll->titulo); ?>
<?php $__env->startSection('content'); ?>
<div class="pubContainer">
    <article class="pub">
        <p class="info"><img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($poll->fecha); ?></p>
        <h2><?php echo e($poll->titulo); ?></h2>
        <p class="info">
            <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($poll->autor); ?>

            <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($poll->visitas); ?> lecturas
        </p>
        <hr />
        <article class="pollOptions">
            <h2>Tu ya votaste!</h2>
            <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <p class="barResult" style="width: <?php echo e(($option->votos * 100) / $totalVotos); ?>%"><?php echo e($option->votos); ?></p>
            <p class="options"><?php echo e($option->opcion); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>No hay opciones</h1>
            <?php endif; ?>
            <p>Votos Totales: <?php echo e($totalVotos); ?></p>
        </article>
        <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
        <div id="fb-root"></div>
        <script>
            (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.2';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    </article>
    <aside class="pubSeccion">
        <?php $__empty_1 = true; $__currentLoopData = $morePolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="morePolls">
            <p><?php echo e($more->fecha); ?></p>
            <a href="<?php echo e(route('poll',['id'=>$more->id,'titulo'=>str_slug($more->titulo,'-')])); ?>"><?php echo e($more->titulo); ?></a>   
        </article> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </aside>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>