<?php $__env->startSection('title', 'Barrilete'); ?>
<?php $__env->startSection('description', 'Secciones de noticias, galerías de fotos, encuestas, toda la actualidad en un solo sitio'); ?>
<?php $__env->startSection('keywords', 'secciones, noticias, economía, editoriales, internacionales, galerías de fotos, tecnología, política, sociedad, encuestas, deportes, cultura'); ?>
<?php $__env->startSection('content'); ?>
<?php ($i=0) ?>
<?php $__empty_1 = true; $__currentLoopData = $articlesIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php ($i++) ?>
<article class="pubIndex">
    <div class="seccion" onclick="location.href ='<?php echo e(route('section',['seccion'=>str_slug($article->section->name)])); ?>'"><?php echo e($article->section->name); ?></div>
    <?php if($article->video == 1): ?><img src="img/play-button.png" class="video" />
    <?php endif; ?>
    <?php if($i == 1): ?>
    <img src="img/articles/images/<?php echo e($article->photo); ?>" title="<?php echo e($article->title); ?>" alt="<?php echo e($article->title); ?>" />
    <?php else: ?>
    <img src="img/articles/.thumbs/images/<?php echo e($article->photo); ?>" title="<?php echo e($article->title); ?>" alt="<?php echo e($article->title); ?>" />
    <?php endif; ?>
    <a href="<?php echo e(route('article',['id'=>$article->id,'section'=>str_slug($article->section->name),'title'=>str_slug($article->title,'-')])); ?>"><?php echo e($article->title); ?></a>
    <p><?php echo e($article->article_desc); ?></p>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<h1>No hay artículos para mostrar</h1>
<?php endif; ?>
<hr />
<div class="galeriasContainerIndex">
    <h1>Galerías de fotos</h1>
    <?php if($galleryIndex): ?>
        <article class="galeriaIndex">
            <img src="img/galleries/<?php echo e($galleryIndex->photos->first()->photo); ?>" title="<?php echo e($galleryIndex->title); ?>" alt="<?php echo e($galleryIndex->title); ?>" />
            <a href="<?php echo e(route('gallery',['id'=>$galleryIndex->id,'titulo'=>str_slug($galleryIndex->title,'-')])); ?>"><?php echo e($galleryIndex->title); ?></a>       
        </article>
    <?php else: ?>
    <h2>No hay galerías</h2>
    <?php endif; ?>
</div>
<div class="pollsContainerIndex">
    <h1>Últimas encuestas</h1>
    <?php $__empty_1 = true; $__currentLoopData = $pollsIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pollIndex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="pollIndex">
        <p><?php echo e($pollIndex->date); ?></p>
        <a href="<?php echo e(route('poll',['id'=>$pollIndex->id,'titulo'=>str_slug($pollIndex->title,'-')])); ?>"><?php echo e($pollIndex->title); ?></a>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h2>No hay encuestas</h2>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>