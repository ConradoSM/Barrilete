<?php $__env->startSection('title', $poll->title); ?>
<?php $__env->startSection('content'); ?>
<div class="pubContainer">
    <article class="pub">
        <p class="info"><img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($poll->date); ?></p>
        <h2><?php echo e($poll->title); ?></h2>
        <p class="copete"><?php echo e($poll->article_desc); ?></p>
        <p class="info">
            <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($poll->user->name); ?>

            <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($poll->views); ?> lecturas
        </p>
        <hr />
        <article class="pollOptions">
            <?php if($status): ?>
            <h2><?php echo e($status); ?></h2>
            <?php $__empty_1 = true; $__currentLoopData = $poll_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <p class="options"><?php echo e($option->option); ?> (<?php echo e($option->votes); ?>)</p>
            <p class="barResult" style="width: <?php echo e(($option->votes * 100) / $totalVotes); ?>%"><?php echo e(round(($option->votes * 100) / $totalVotes )); ?>%</p>           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>No hay opciones</h1>
            <?php endif; ?>
            <p>Votos: <?php echo e($totalVotes); ?></p>
            <?php else: ?>
            <form action="<?php echo e(route('poll-vote')); ?>" method="post">            
                <?php $__empty_1 = true; $__currentLoopData = $poll_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <label class="radio-container" for="<?php echo e($option->id); ?>"><?php echo e($option->option); ?>

                    <input type="radio" name="id_opcion" id="<?php echo e($option->id); ?>" value="<?php echo e($option->id); ?>" required />
                    <span class="checkmark"></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>No hay opciones</h1>
                <?php endif; ?>           
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_encuesta" value="<?php echo e($poll->id); ?>" />
                <input type="hidden" name="ip" value="<?php echo e(Request::ip()); ?>" />
                <input type="hidden" name="titulo_encuesta" value="<?php echo e(str_slug($poll->title,'-')); ?>" />
                <input type="submit" name="submit" value="VOTAR" />
            </form>
            <?php endif; ?>
        </article>
        <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
        <div id="fb-root"></div>
        <script>
            (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.2';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    </article>
    <aside class="pubSeccion">
        <?php $__empty_1 = true; $__currentLoopData = $morePolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="morePolls">
            <p><?php echo e($more->fecha); ?></p>
            <a href="<?php echo e(route('poll',['id'=>$more->id,'titulo'=>str_slug($more->titulo,'-')])); ?>"><?php echo e($more->titulo); ?></a>   
        </article> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </aside>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>