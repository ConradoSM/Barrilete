<div id="Article-container">
    <h1>Administrar galería de fotos</h1>
    <div class="article-admin">
        <?php if(Auth::user()->is_admin): ?>
            <?php if($gallery->status == "DRAFT"): ?>
                <a href="<?php echo e(route('publishGallery',['id'=>$gallery->id])); ?>" class="edit" id="publish">Publicar</a>
            <?php else: ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('gallery',['id'=>$gallery->id,'section'=>str_slug($gallery->section->name),'title'=>str_slug($gallery->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
            <?php endif; ?>      
            <a href="<?php echo e(route('formUpdateGallery',['id'=>$gallery->id])); ?>" class="edit" id="edit">Editar</a>
            <a href="<?php echo e(route('deleteGallery',['id'=>$gallery->id])); ?>" class="delete" id="delete">Eliminar</a>
        <?php else: ?>
            <?php if($gallery->status == "PUBLISHED"): ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('gallery',['id'=>$gallery->id,'section'=>str_slug($gallery->section->name),'title'=>str_slug($gallery->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
                <a href="<?php echo e(route('formUpdateGallery',['id'=>$gallery->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deleteGallery',['id'=>$gallery->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php else: ?>
                <a href="#" class="disabled">No publicado</a>
                <a href="<?php echo e(route('formUpdateGallery',['id'=>$gallery->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deleteGallery',['id'=>$gallery->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <hr />
    <article class="pub_galeria">
        <h2><?php echo e($gallery->title); ?></h2>        
        <p class="copete"><?php echo e($gallery->article_desc); ?></p>
        <p class="info">
        <img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($gallery->date); ?>

        <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($gallery->user->name); ?>

        <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($gallery->views); ?> lecturas
        </p>
        <br />
    </article>
    <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="fotos">
        <img src="<?php echo e(asset('img/galleries/'.$photo->photo)); ?>" />
        <p><?php echo e($photo->title); ?></p>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay fotos</p>
    <?php endif; ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin-links.js')); ?>"></script>
</div>