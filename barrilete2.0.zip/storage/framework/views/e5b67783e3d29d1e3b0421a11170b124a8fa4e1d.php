<?php $__env->startSection('title', __('Register')); ?>
<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <div class="dashboard-login">
        <p><img src="<?php echo e(asset('svg/adding-users.svg')); ?>" /><?php echo e(__('Register')); ?></p>
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Name')); ?>" required autofocus>
            <?php if($errors->has('name')): ?><p class="invalid-feedback" role="alert"><?php echo e($errors->first('name')); ?></p><?php endif; ?>
            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>" required>
            <?php if($errors->has('email')): ?><p class="invalid-feedback" role="alert"><?php echo e($errors->first('email')); ?></p><?php endif; ?>
            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
            <?php if($errors->has('password')): ?><p class="invalid-feedback" role="alert"><?php echo e($errors->first('password')); ?></p><?php endif; ?>
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="<?php echo e(__('Confirm Password')); ?>" required>
            <input type="submit" value="<?php echo e(__('Register')); ?>" />
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>