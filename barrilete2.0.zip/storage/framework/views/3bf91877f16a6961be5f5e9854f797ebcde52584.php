<h2>Borrar Galería de fotos</h2>
<?php if($status == 'success'): ?>
	<p class="alert-success">La galería de fotos se ha eliminado correctamente del sistema.</p>
<?php else: ?>
	<p class="invalid-feedback">Ha ocurrido un error al borrar la galería de fotos.</p>
<?php endif; ?>