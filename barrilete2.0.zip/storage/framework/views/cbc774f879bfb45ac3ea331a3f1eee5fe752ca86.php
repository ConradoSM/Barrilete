<?php $__env->startSection('content'); ?>
<div class="dashboard-main-container">
        <div class="user-bar">
            <?php if(session('status')): ?>
            <div><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <div class="menu-user">
                <p><?php echo e(Auth::user()->name); ?><img src="/svg/arrow-down.svg" /></p>
                <nav>
                    <ul>
                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a></li>
                    </ul>               
                </nav>
            </div>
            
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>