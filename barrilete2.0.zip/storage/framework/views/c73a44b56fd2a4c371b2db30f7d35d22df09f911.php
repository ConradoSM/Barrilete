<?php $__env->startSection('title', $gallery->title); ?>
<?php $__env->startSection('content'); ?>
<div class="pubContainer">
<article class="pub_galeria">
    <p class="info"><img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($gallery->date); ?></p>
    <h2><?php echo e($gallery->title); ?></h2>
    <p class="copete"><?php echo e($gallery->article_desc); ?></p>
    <p class="info">
    <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($gallery->user->name); ?>

    <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($gallery->views); ?> lecturas
    </p>
    <hr />
</article>
<?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<article class="fotos">
    <img src="<?php echo e(asset('img/galleries/'.$photo->photo)); ?>" />
    <p><?php echo e($photo->title); ?></p>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1>No hay fotos</h1>
<?php endif; ?>
<div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.2';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>