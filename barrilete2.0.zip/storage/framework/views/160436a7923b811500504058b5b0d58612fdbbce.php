<?php $__env->startSection('title', 'Barrilete'); ?>
<?php $__env->startSection('content'); ?>
<?php ($i=0) ?>
<?php $__empty_1 = true; $__currentLoopData = $titularesIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tituloIndex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php ($i++) ?>
<article class="pubIndex">
    <div class="seccion" onclick="location.href ='<?php echo e(route('section', ['seccion' => str_slug($tituloIndex -> seccion)])); ?>'"><?php echo e($tituloIndex -> seccion); ?></div>
    <?php if($tituloIndex -> video == 1): ?><img src="img/play-button.png" class="video" /><?php endif; ?>
    <?php if($i == 1): ?>
    <img src="img/articles/<?php echo e($tituloIndex->foto); ?>" title="<?php echo e($tituloIndex -> titulo); ?>" alt="<?php echo e($tituloIndex -> titulo); ?>" />
    <?php else: ?>
    <img src="<?php echo e(route('imgFirst', ['image'=>$tituloIndex->foto])); ?>" title="<?php echo e($tituloIndex -> titulo); ?>" alt="<?php echo e($tituloIndex -> titulo); ?>" />
    <?php endif; ?>
    <a href="<?php echo e(route('article', ['id' => $tituloIndex -> id, 'seccion' => str_slug($tituloIndex -> seccion), 'titulo' => str_slug($tituloIndex -> titulo, '-')])); ?>"><?php echo e($tituloIndex -> titulo); ?></a>
    <p><?php echo e($tituloIndex -> copete); ?></p>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<h1>No hay artículos para mostrar</h1>
<?php endif; ?>
<hr />
<div class="galeriasContainerIndex">
    <h1>Galerías de fotos</h1>
    <article class="galeriaIndex">
        <img src="<?php echo e(route('imgSecond', ['image' => $galeriasIndex->foto])); ?>" title="<?php echo e($galeriasIndex->titulo); ?>" alt="<?php echo e($galeriasIndex->titulo); ?>" />
        <a href="<?php echo e(route('gallery', ['id' => $galeriasIndex->id, 'titulo' => str_slug($galeriasIndex->titulo, '-')])); ?>"><?php echo e($galeriasIndex->titulo); ?></a>       
    </article>
</div>
<div class="pollsContainerIndex">
    <h1>Últimas encuestas</h1>
    <?php $__empty_1 = true; $__currentLoopData = $pollsIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pollIndex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="pollIndex">
        <p><?php echo e($pollIndex->fecha); ?></p>
        <a href="<?php echo e(route('poll', ['id' => $pollIndex->id, 'titulo' => str_slug($pollIndex->titulo, '-')])); ?>"><?php echo e($pollIndex->titulo); ?></a>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1>NO HAY ENCUESTAS PARA MOSTRAR</h1>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>