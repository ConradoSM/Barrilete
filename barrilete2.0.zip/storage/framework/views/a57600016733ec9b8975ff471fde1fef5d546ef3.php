<?php $__env->startSection('title', $article->title); ?>
<?php $__env->startSection('description', $article->article_desc); ?>
<?php $__env->startSection('keywords', 'secciones, noticias, economía, editoriales, internacionales, galerías de fotos, tecnología, política, sociedad, encuestas, deportes, cultura'); ?>
<?php $__env->startSection('content'); ?>
<div class="pubContainer">
<article class="pub">
    <img src="<?php echo e(asset('img/articles/images/'.$article->photo)); ?>" title="<?php echo e($article->title); ?>" alt="<?php echo e($article->title); ?>" />
    <p class="info"><img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($article->date); ?></p>
    <h2><?php echo e($article -> title); ?></h2>
    <p class="copete"><?php echo e($article->article_desc); ?></p>
    <p class="info">
    <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($article->user->name); ?>

    <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($article->views); ?> lecturas
    </p>
    <hr />
    <?php echo $article->article_body; ?>

    <hr />
<div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.2';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</article>
<aside class="pubSeccion">
    <?php $__empty_1 = true; $__currentLoopData = $moreArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="pubArticle">
        <a href="<?php echo e(route('article', ['id' => $more -> id, 'section' => str_slug($article->section->name), 'title' => str_slug($more -> title, '-')])); ?>"><?php echo e($more -> title); ?></a>
        <img src="/img/articles/.thumbs/images/<?php echo e($more -> photo); ?>" title="<?php echo e($more -> title); ?>" alt="<?php echo e($more -> title); ?>" />   
    </article> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
</aside>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.barrilete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>