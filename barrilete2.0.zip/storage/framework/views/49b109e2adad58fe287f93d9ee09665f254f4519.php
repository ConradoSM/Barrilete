<div id="Article-container">
    <h1>Administrar encuestas</h1>
    <div class="article-admin">
        <?php if(Auth::user()->is_admin): ?>
            <?php if($poll->status == "DRAFT"): ?>
                <a href="<?php echo e(route('publishPoll',['id'=>$poll->id])); ?>" class="edit" id="publish">Publicar</a>
            <?php else: ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('poll',['id'=>$poll->id,'section'=>str_slug($poll->section->name),'title'=>str_slug($poll->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
            <?php endif; ?>      
            <a href="<?php echo e(route('formUpdatePoll',['id'=>$poll->id])); ?>" class="edit" id="edit">Editar</a>
            <a href="<?php echo e(route('deletePoll',['id'=>$poll->id])); ?>" class="delete" id="delete">Eliminar</a>
        <?php else: ?>
            <?php if($poll->status == "PUBLISHED"): ?>
                <a href="#" class="disabled">Publicado</a>
                <a href="<?php echo e(route('poll',['id'=>$poll->id,'section'=>str_slug($poll->section->name),'title'=>str_slug($poll->title,'-')])); ?>" target="_blank" class="edit">Ver artículo</a>
                <a href="<?php echo e(route('formUpdatePoll',['id'=>$poll->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deletePoll',['id'=>$poll->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php else: ?>
                <a href="#" class="disabled">No publicado</a>
                <a href="<?php echo e(route('formUpdatePoll',['id'=>$poll->id])); ?>" class="edit" id="edit">Editar</a>
                <a href="<?php echo e(route('deletePoll',['id'=>$poll->id])); ?>" class="delete" id="delete">Eliminar</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <hr />
    <article class="pub_galeria">
    <h2><?php echo e($poll->title); ?></h2>
    <p class="copete"><?php echo e($poll->article_desc); ?></p>
    <p class="info">
        <img class="svg" src="<?php echo e(asset('svg/calendar.svg')); ?>" /> <?php echo e($poll->date); ?>

        <img class="svg" src="<?php echo e(asset('svg/user_black.svg')); ?>" /> <?php echo e($poll->user->name); ?>

        <img class="svg" src="<?php echo e(asset('svg/eye.svg')); ?>" /> <?php echo e($poll->views); ?> lecturas
    </p>
    </article>
    <hr />
    <article class="pollOptions">
        <form action="#" method="post">            
            <?php $__empty_1 = true; $__currentLoopData = $poll_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <label class="radio-container" for="<?php echo e($option->id); ?>"><?php echo e($option->option); ?>

                <input type="radio" name="id_opcion" id="<?php echo e($option->id); ?>" value="<?php echo e($option->id); ?>" required />
                <span class="checkmark"></span>
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>No hay opciones</h1>
            <?php endif; ?>
            <input type="submit" value="VOTAR" disabled />
        </form>
    </article>
<br />
<script type="text/javascript" src="<?php echo e(asset('js/admin-links.js')); ?>"></script>
</div>