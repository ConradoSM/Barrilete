<center>
    <a href="https://barrilete.com.ar/"><img src="https://barrilete.com.ar/svg/logo_barrilete.svg"></a>
    <h2>v.2.0 BETA</h2>
</center>

