<nav class="none">
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li><a href="<?php echo e(route('section',['seccion'=>$section->name])); ?>" title="<?php echo e($section->name); ?>"><?php echo e($section->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?> 
    </ul>
</nav>
